/*
******************************************************************************
* @file 	  AppDriverCommand.c
* @author	  Sang
* @date 	  2024-12
* @brief	  Printer command layer (application layer)
*
*			  This file provides firmware functions to manage the following
*			  functionalities:
*			  + data parsing instruction
*/
#include "AppDriverGeneric.h"//JL lib dependency
#include "AppDriver.h"
#include "queue.h"
#include "string.h"
#include "zlib.h"


PDataPacket PrintBLink=NULL;//print linked list
unsigned long LineCount=0;
Command command={NULL,0,0,0,CommandIdle,830,19,LablePaper,80,0,0,0,false,false,0,NULL,32,{0},0};//cpmmand processer buffer
#define CMDHeadCount	8
const CommandHead CMDHead[CMDHeadCount]=//command list
{
{4,{0x40,0x53,0x4d,0x53}},//speed command
{4,{0x40,0x53,0x7E,0x7E}},//density command
{4,{0x40,0x53,0x50,0x50}},//paper types
{2,{'@','<'}},//page start command
{2,{'#','<'}},//line start command
{2,{'#','>'}},//line end command
{2,{'@','>'}},//page end command
{6,{'A','N','G','E','N','L'}},//zip command
};
void ReturnModle(void)
{
	command.LineDecodeOneceFinshed=true;
	command.ReturnFlag=true;
	command.RemainderLength=command.TotalLength-command.ReadPos;
}
static unsigned int CalculateAccSteps(unsigned int Speed)
{
	for(unsigned int i=0;i<31;i++)
		if(Speed>=TableSpeedUS[i])return i;
	return 30;
}
void CommandSetSpeed(void)
{
	if(command.ReadPos+2<command.TotalLength)//if remainder data is enough
	{
		command.Speed=((unsigned int)command.Buffer[command.ReadPos])*256+command.Buffer[command.ReadPos+1];
		command.ReadPos+=2;
		command.AccSteps=CalculateAccSteps(command.Speed);
		printf("Speed-->%d-Acc:%d\n",command.Speed,command.AccSteps);
		command.DecodeStatus=CommandIdle;//

		return;
	}
	ReturnModle();
}
void CommandSetDensity(void)
{
	if(command.ReadPos+1<command.TotalLength)//if remainder data is enough
	{
		command.density=command.Buffer[command.ReadPos++];
		if(command.density<45)
			command.density=45;
		printf("density-->%d\n",command.density);
		command.DecodeStatus=CommandIdle;//
		return;
	}
	ReturnModle();
}
void CommandSetPaperType(void)
{
	if(command.ReadPos+1<command.TotalLength)//if remainder data is enough
	{
		command.PaperType=command.Buffer[command.ReadPos++];
		printf("PaperType-->%d\n",command.PaperType);
		command.DecodeStatus=CommandIdle;//
		return;
	}
	ReturnModle();
}

void CommandSetPageStart(void)
{
	printf("page start -->\n");
	command.DecodeStatus=CommandIdle;
	command.PageEndFlag=false;
	LineCount=0;
	printf("PrintBLink.PageNum:%d\r\n",command.PageNum);
}
void WritePrintLinkedList(void)
{
	LinkedListData LLData;
	LLData.PageNum=command.PageNum;
	LLData.len=108;
	LLData.data=(unsigned char*)malloc(LLData.len*sizeof(unsigned char));
	memcpy(LLData.data,command.DotsMatric,LLData.len);
	_malloc(&PrintBLink,LLData);//save data in linked list
	free(LLData.data);


}
void CommandSetLineStart(void)
{
	static unsigned char DotValue=0;
	const unsigned char Cmp[]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
	command.LineDecodeOneceFinshed=false;
	while(!command.LineDecodeOneceFinshed)//wait line decode end
	{
		switch(command.LineDeCodeWrite)
		{
			case 0://categery
				if(command.ReadPos+1<command.TotalLength)//if remainder data is enough
				{
					if(command.Buffer[command.ReadPos]&0x80)//repeat dots flag
					{
						command.LineDeCodeWrite=1;//repeat dots calculate goes to the subsequent case
						DotValue=0;
						if(command.Buffer[command.ReadPos]&0x7f)//gray value
						{
							DotValue=1;
						}
					}
					else
					{
						if(command.Buffer[command.ReadPos]&0x7f)
						{
							command.DotsMatric[command.Dots/8]|=Cmp[command.Dots%8];//file print buffer
						}
						command.Dots++;//record dots
					//	printf("1Dots:%d-%d-1\n",command.Dots,DotValue);
						if(command.Dots>=LineDecodeDots)//line dots decodes finsh
						{
							command.DecodeStatus=CommandIdle;
							command.LineDecodeOneceFinshed=true;
							WritePrintLinkedList();
							LineCount++;
							//printf("L2:%d-Dots:%d\n",LineCount,command.Dots);
						}
					}
					command.ReadPos++;
				}
				else
					ReturnModle();
				break;
			case 1://successive value
				if(command.ReadPos+1<command.TotalLength)//if remainder data is enough
				{
					unsigned int LineDots=(unsigned int)command.Buffer[command.ReadPos++]+1;//overlapped data

					if(DotValue)
					{
						for(unsigned int i=0;i<LineDots;i++)
						{
							command.DotsMatric[(command.Dots+i)/8]|=Cmp[(command.Dots+i)%8];//file print buffer
						}
					}
					command.Dots+=LineDots;
				//	printf("2Dots:%d-%d-%d\n",command.Dots,DotValue,LineDots);
					if(command.Dots>=LineDecodeDots)
					{
						command.DecodeStatus=CommandIdle;
						command.LineDecodeOneceFinshed=true;
						WritePrintLinkedList();
						LineCount++;
						//printf("L1:%d-Dots:%d\n",LineCount,command.Dots);
					}
					command.LineDeCodeWrite=0;// enter case decode data
				}
				else
					ReturnModle();
				break;

		}
	}
}
void CommandSetLineEnd(void)
{
	command.DecodeStatus=CommandIdle;
}
void CommandSetPageEnd(void)
{
	printf("Page end\r\n");
	command.DecodeStatus=CommandIdle;
	command.PageEndFlag=true;
	command.PageNum++;//pages unique ID
	printf("PrintBLink.PageNum:%d\r\n",command.PageNum);
}
static void IdleProces(void)
{
	for(int i=0;i<CMDHeadCount;i++)
	{
		if(command.ReadPos+CMDHead[i].len<command.TotalLength)//if remainder data is enough
		{
			if(!memcmp(command.Buffer+command.ReadPos,CMDHead[i].CommandContent,CMDHead[i].len))//compare command head
			{
				//printf("Find command:%d>\r\n",i);
				command.ReadPos+=CMDHead[i].len;//shift read
				command.DecodeStatus=i;//DecodeStatus ID
				if(command.DecodeStatus==CommandLineStart||command.DecodeStatus==CommandZipData)
				{
					command.LineDeCodeWrite=0;//decode function switch
					command.Dots=16;
					memset(command.DotsMatric,0,sizeof(command.DotsMatric));
				}
				return;
			}
		}
	}
//	printf("<%c>\n",command.Buffer[command.ReadPos]);
	if(command.ReadPos+MAxHeadLength<command.TotalLength)//if remainder data is enough
		command.ReadPos++;
	else
		ReturnModle();

}
static void CommandZipSize(void)
{
	if(command.ReadPos+2<command.TotalLength)//if remainder data is enough
	{
		command.ZipSize=((unsigned int)command.Buffer[command.ReadPos])*256+command.Buffer[command.ReadPos+1];
		command.ReadPos+=2;
		printf("ZipSize-->%d\n",command.ZipSize);
		command.DecodeStatus=CommandZipData;//
		return;
	}
	ReturnModle();
}
static void CommandZipFetchData(void)
{
	static unsigned int Write=0;
	if(command.zipData==NULL)
		command.zipData=(unsigned char*)malloc(command.ZipSize*sizeof(unsigned char));
	while(Write<command.ZipSize)
	{
		if(command.ReadPos+1<=command.TotalLength)//if remainder data is enough
		{
			command.zipData[Write++]=command.Buffer[command.ReadPos++];continue;
		}
		ReturnModle();
		break;
	}
	if(Write>=command.ZipSize)
	{
		printf("zip decode finished!\n");
		command.DecodeStatus=CommandIdle;
		ZipDecode(command.zipData,command.ZipSize);
		free(command.zipData);
		command.zipData=NULL;
		Write=0;
	}
}
static void PrintDataProcesser(void)
{
	while(!command.ReturnFlag)// if status is return modle ,then exit the function
	{
		switch(command.DecodeStatus)
		{
			case CommandSpeed:CommandSetSpeed();break;
			case CommandDensity:CommandSetDensity();break;
			case CommandPaperType:CommandSetPaperType();break;
			case CommandPageStart:CommandSetPageStart();break;
			case CommandLineStart:CommandSetLineStart();break;
			case CommandLineEnd:CommandSetLineEnd();break;
			case CommandPageEnd:CommandSetPageEnd();break;
			case CommandZipStart:CommandZipSize();break;
			case CommandZipData:CommandZipFetchData();break;
			default:IdleProces();break;
		}
	}
}
// decode function，use Deflate decode algorithm
int ZipDecode(unsigned char *ZipData,unsigned int len)
{
    DataPacket Dp;
	unsigned char out[1000];
    z_stream strm;
    int ret;
	unsigned long CurrentPos=0;
    // initialize data stream
    memset(&strm, 0, sizeof(strm));
    ret = inflateInit2(&strm, -15); //   Deflate format
    if (ret != Z_OK)
	{
        printf("inflateInit2 failed with error: %d\n", ret);
        return ret;
    }
	strm.avail_in=len;	//zip data len
	strm.next_in = ZipData; 	//pointer to the zip data
	// decode loop
	do
	{
		strm.avail_out = 1000; //set max size once
		strm.next_out = out;
		// excecute inflate algorithm
		ret = inflate(&strm, Z_NO_FLUSH);
		switch (ret)
		{
                case Z_NEED_DICT:
                case Z_DATA_ERROR:
                case Z_MEM_ERROR:
                    printf("inflate failed with error: %d\n", ret);
                    inflateEnd(&strm);
                    return ret;
		}
		CurrentPos=strm.total_out-CurrentPos;
		while(PrintDataManagement(CurrentPos,out)==false)//recursion
		{
			os_time_dly(2);
		}

		free(Dp.LLData.data);
		CurrentPos=strm.total_out;
	}
	while (strm.avail_out == 0);
    inflateEnd(&strm); // release resource
}

bool PrintDataManagement(unsigned int len,unsigned char *data)
{
	unsigned int NodeCount=_malloc_size(PrintBLink);//calculate node quantity
	if(NodeCount<PrintLinkedListCount)
	{
		_realloc(len,data,&command);//write process  memory
		PrintDataProcesser();//data process
		return true;
	}
	return false;
}
//write Empty page
void WriteEmptyPage(unsigned int Dots)
{
	unsigned char Buffer[1000];
	unsigned int Pwrite=0;
	memcpy(Buffer,"@<0000",6);
	Pwrite+=6;

}
void Print(void)
{
 	CoverOperation();//this function manage the cover operation
 	EventBits_t bits = xEventGroupWaitBits(Printer_event_group,PrinterReady_BIT,pdFALSE,pdFALSE,pdMS_TO_TICKS(100));
	if (!(bits & PrinterReady_BIT)||SMP.Status==Running) return;//if printer cover detected and finding paper edge finished,and step motor stopped then enter into printing process.
	unsigned int NodeCount=_malloc_size(PrintBLink);//calculate node quantity of print buffer
	if(NodeCount>PrintLinkedListSP)//
	{
		if(Gap.paperPosition==CutPos)
		{
			StepMP SMPPrintPos={9,0,0,false,Backward,Stopped,ModeFixSteps,164,false,false,false,false,false};
			StepMotorStart(SMPPrintPos);
			while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
			pdMS_TO_TICKS(200);
			StepMP SMPPrintPos1={4,0,0,false,Forward,Stopped,ModeFixSteps,4,false,false,false,false,false};
			StepMotorStart(SMPPrintPos1);
			while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
			Gap.paperPosition=PrintPos;
			pdMS_TO_TICKS(200);
		}
		StepMP SMPCurrent={command.AccSteps,0,0,false,Forward,Stopped,ModeContinue,0,false,true,false,true,true};//print parameters
		//StepMP SMPCurrent={8,0,0,false,Forward,Stopped,ModeContinue,0,false,true,false,true,true};//print parameters
		StepMotorStart(SMPCurrent);//start motor to print
		for(;SMP.Status==Running;)vTaskDelay(pdMS_TO_TICKS(100));//waiting for the print finished.
		if(Page.SensorError) 
		{
			SensorErrDuringPrintProcess();//sensor error return to task
			return;
		}
		vTaskDelay(pdMS_TO_TICKS(200));//stable delay
		if(Page.EliminateRedundanctData)//
		{
			printf("enter into the moving redundant data process");
			RedundantDataProcessing(true);
		}
		Page.ContinuePrint=false;
		vTaskDelay(pdMS_TO_TICKS(800));//stable delay
		NodeCount=_malloc_size(PrintBLink);//calculate node quantity of print buffer
		if(NodeCount>PrintLinkedListSP) 
		{
			printf("Print continue>>>\n");
			Page.ContinuePrint=true;
			return;//continue to print
		}
		printf("step motor runs to cut position...\n");
		StepMP SMPCut={9,0,0,false,Forward,Stopped,ModeFixSteps,160,false,false,false,false};
		StepMotorStart(SMPCut);
		while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
		Gap.paperPosition=CutPos;
	}
}

/**
 * @brief PrintTask.
 * @param p:Task Parameter Pass.
 * @return none
 */
void PrintTask(void *p)
{
    int msg[16];
	int Count=0;
    while(1)
    {
    	Print();									//print data
		__os_taskq_pend(msg, ARRAY_SIZE(msg), 2);
    }
}


