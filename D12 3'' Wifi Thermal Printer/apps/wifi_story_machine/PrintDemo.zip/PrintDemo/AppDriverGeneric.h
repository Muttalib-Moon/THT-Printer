

#ifdef __cplusplus
extern "C" {
#endif


#include "system/app_core.h"
#include "system/includes.h"
#include "server/server_core.h"
#include "asm/power_interface.h"
#include "event/bt_event.h"
#include "event/event.h"
#include "syscfg/syscfg_id.h"
#include "app_config.h"
#include "os/os_api.h"
//#include "system/malloc.h"
#include "bt_common.h"
#include "btstack_typedef.h"
#include "string.h"
#include "device/gpio.h"
#include "asm/adc_api.h"

#include "FreeRTOS.h"
#include "task.h"
#include "event_groups.h"
#include "queue.h"





//global variable

//functions in AppDriverBase.c
void SysReset(void);
void Debug(const char* format, ...);

//declaration of functions
void USBPrinterReveiveDataTask(void);
//-----Macro of LED
#define LEDErrGpio		JL_PORTA->OUT
#define LEDErrGpioIO	IO_PORTA_00
#define LEDErrGpioIOBit	 BIT(0)

#define	LEDErrTurnOff		LEDErrGpio|=LEDErrGpioIOBit
#define	LEDErrTurnOn		LEDErrGpio&=~LEDErrGpioIOBit

#define LEDLineGpio		JL_PORTH->OUT
#define LEDLineGpioIO	IO_PORTH_09
#define LEDLineGpioIOBit	 BIT(9)

#define	LEDLineTurnOff		LEDLineGpio|=LEDLineGpioIOBit
#define	LEDLineTurnOn		LEDLineGpio&=~LEDLineGpioIOBit
	
//-----------------------------Macro of step motor-----------------------------
#define Forward			0
#define Backward		1

#define Stopped			0
#define Running			1

#define ModeContinue		0
#define ModeFixSteps		1


#define USIRAM SEC_USED(.volatile_ram_code)
#define TimerStepMotorCON	JL_TIMER4->CON
#define TimerStepMotorPRD	JL_TIMER4->PRD
#define TimerStepMotorCNT	JL_TIMER4->CNT


#define TimerIntervalCON	JL_TIMER1->CON
#define TimerIntervalPRD	JL_TIMER1->PRD
#define TimerIntervalCNT	JL_TIMER1->CNT


//Macro of step motor IO
#define PortStepMotorCurrentI0Gpio	JL_PORTA->OUT
#define PortStepMotorCurrentI0IO	IO_PORTA_10
#define PortStepMotorCurrentI0IOBit	BIT(10)

#define PortStepMotorCurrentI1Gpio	JL_PORTB->OUT
#define PortStepMotorCurrentI1IO	IO_PORTB_05
#define PortStepMotorCurrentI1IOBit	BIT(5)

#define PortStepMotorEnableGpio		JL_PORTA->OUT
#define PortStepMotorEnableIO		IO_PORTA_06
#define PortStepMotorEnableIOBit	BIT(6)

#define PortStepMotorPhaseAGpio		JL_PORTA->OUT
#define PortStepMotorPhaseAIO		IO_PORTA_05
#define PortStepMotorPhaseAIOBit	BIT(5)

#define PortStepMotorPhaseBGpio		JL_PORTA->OUT
#define PortStepMotorPhaseBIO		IO_PORTA_09
#define PortStepMotorPhaseBIOBit	BIT(9)

#define PortDriverPowerPulse		JL_PORTB->OUT
#define PortDriverPowerPulseIO		IO_PORTB_06
#define PortDriverPowerPulseIOBit	BIT(6)

//TimerStepMotorCON&=~BIT(0);	//close timer
//TimerIntervalCON&=~BIT(0);		//close driver power

#define	StepMotorCurrentI0TurnOff			PortStepMotorCurrentI0Gpio|=PortStepMotorCurrentI0IOBit
#define	StepMotorCurrentI0TurnOn			PortStepMotorCurrentI0Gpio&=~PortStepMotorCurrentI0IOBit

#define	StepMotorCurrentI1TurnOff			PortStepMotorCurrentI1Gpio|=PortStepMotorCurrentI1IOBit
#define	StepMotorCurrentI1TurnOn			PortStepMotorCurrentI1Gpio&=~PortStepMotorCurrentI1IOBit
#define StepMotorCurrentOn					StepMotorCurrentI0TurnOn;StepMotorCurrentI1TurnOn;
#define StepMotorCurrentOFF					StepMotorCurrentI0TurnOff;StepMotorCurrentI1TurnOff;

#define	StepMotorIOEnable					PortStepMotorEnableGpio|=PortStepMotorEnableIOBit
#define	StepMotorIOdisable					PortStepMotorEnableGpio&=~PortStepMotorEnableIOBit

#define	StepMotorEnable						StepMotorIOEnable;StepMotorCurrentOn;TimerStepMotorCON|=BIT(0);TimerIntervalCON|=BIT(0);
#define	StepMotordisable					StepMotorIOdisable;StepMotorCurrentOFF;TimerIntervalCON&=~BIT(0);TimerStepMotorCON&=~BIT(0);


#define	StepMotorPhaseAHigh					PortStepMotorPhaseAGpio|=PortStepMotorPhaseAIOBit
#define	StepMotorPhaseALow					PortStepMotorPhaseAGpio&=~PortStepMotorPhaseAIOBit

#define	StepMotorPhaseBHigh					PortStepMotorPhaseBGpio|=PortStepMotorPhaseBIOBit
#define	StepMotorPhaseBLow					PortStepMotorPhaseBGpio&=~PortStepMotorPhaseBIOBit

//#define	PortDriverPowerPulseHigh			PortDriverPowerPulse|=PortDriverPowerPulseIOBit
//#define	PortDriverPowerPulseLow				PortDriverPowerPulse&=~PortDriverPowerPulseIOBit
#define	PortDriverPowerPulseAvert			PortDriverPowerPulse^=PortDriverPowerPulseIOBit


#define Step1IO			StepMotorPhaseAHigh;StepMotorPhaseBHigh;
#define Step2IO			StepMotorPhaseALow;StepMotorPhaseBHigh;
#define Step3IO			StepMotorPhaseALow;StepMotorPhaseBLow;
#define Step4IO			StepMotorPhaseAHigh;StepMotorPhaseBLow;

typedef struct StepMotorRunningParameter
{
	unsigned int  ACCSteps;		//accelerate steps
	unsigned long CurrentSteps; //record Current steps
	unsigned int CurrentDecSteps;//record deceleration steps
	bool Suspend;				//manipulate running stablility of the step motor
	unsigned char Dir;			//step motor runs direction
	unsigned char Status;		//Step motor status,0:stopped,1:running
	unsigned char Mode;			//step motor control mode 0:continue 1:fix steps
	unsigned int StepsFixedValue;//if the mode is fix steps this value is the steps step motor runs
	bool StepMotorFinished;		//this is a indicatator for interrup function
	bool HeadPrint;				//head print flag, true:print false:only move step motor
	bool FindPaperEdge;					//find paper edge function	true:step motor find paper edge; false: this operation is forbidden
	bool RecordGap;					//true:when motor runs forward the gap informatrion will be recorded and calculated
	//
	bool CalculateCompensate;	//This value uses in the powerOn or cover close operation

	
	
}StepMP;

typedef struct PRINTPAGE
{
	unsigned int CurrentLine;		//Current printing line in one page
	int RemainderSteps;	//current page remainder steps
	unsigned long PageNum;			//this value is current printing page
	bool EliminateRedundanctData;	//this value used when the redundant data can't be removed during the Gap moving,the motor will stopped and delete the left page data
	bool SensorError;
	bool ContinuePrint;
}PrintPage;
#define PrintPos	0
#define CutPos		1

typedef struct GapAndPaper
{
	unsigned int LabelLength;		//label length steps calculates by sensor
	unsigned long StepsCount;		//
	unsigned long StepsGapPos; 		//record the gap in location
	unsigned int LabelGapLength;	//label gap length
	unsigned char CountGap;			//Gap Status bit
	bool GapIn;						//label gap on sensor flag
	unsigned char CountPaper;		//count paper sensor status
	unsigned char paperPosition;	//print position:0 cut paper position:1
	unsigned int LableLengthCP;		//record the power on page length when power on
	unsigned int CountLable;
	


	

}GAP;

extern GAP Gap;

//ADC channel
enum ADCChannelName
{
	ADCKeyBoard=0,			//key press 900,key up 0  
	ADCPaperEdge,			//paper cover :0 paper off 900 ;cover close:800
	ADCPowerOnOff,			//key working power 1000:key off ;0:key on
	ADCGAPSensor,			//Paper area:800,gap area:300
	ADCThermoneter,			//Thermometer 25 degree:750 -->50 degree,10k=ADC 512;-->60 degree,7.5K=ADC 438
	ADCUSBVoltage,			//USB voltage 1000:USB on,0:USB off
	ADCMemoryLimit,
};

//----------------------------------Macro of thermal printer head----------------------------------
//PWM timer3 macro
#define    TimerPWMCON JL_TIMER3->CON
#define	   TimerPWMPRD JL_TIMER3->PRD
#define	   TimerPWMPWM JL_TIMER3->PWM
#define	   TimerPWMCNT JL_TIMER3->CNT
//strobe
#define HeadstrobeGpio	JL_PORTC->OUT
#define HeadstrobeIO	IO_PORTC_10
#define HeadstrobeIOBit	(0x0001<<10)
#define HeadstrobeEnable					HeadstrobeGpio|=0x0400
#define HeadstrobeDisable					HeadstrobeGpio&=~0x0400
//latch
#define HeadLatchGpio	JL_PORTC->OUT
#define HeadLatchIO		IO_PORTC_07
#define HeadLatchIOBit	(0x0001<<7)
#define HeadLatchHigh						HeadLatchGpio|=HeadLatchIOBit
#define HeadLatchLow						HeadLatchGpio&=~HeadLatchIOBit
#define HeadLatchIn							HeadLatchGpio|=HeadLatchIOBit;HeadLatchGpio&=~HeadLatchIOBit;HeadLatchGpio&=~HeadLatchIOBit;HeadLatchGpio|=HeadLatchIOBit;
#define SPIHead		JL_SPI2
#define SPI2CON 	SPIHead->CON
#define SPI2BAUD	SPIHead->BAUD
#define SPI2BUF 	SPIHead->BUF
#define SPI2ADR 	SPIHead->ADR
#define SPI2CNT 	SPIHead->CNT
//clock
#define HeadClkGpio		JL_PORTA->OUT
#define HeadClkIO		IO_PORTA_03
#define HeadClkIOBit	(0x0001<<3)
#define HeadClkHigh							HeadClkGpio|=HeadClkIOBit
#define HeadClkLow							HeadClkGpio&=~HeadClkIOBit
//data
#define HeadDataGpio	JL_PORTA->OUT
#define HeadDataIO		IO_PORTA_04
#define HeadDataIOBit	(0x0001<<4)
#define HeadDataHigh						HeadDataGpio|=HeadDataIOBit
#define HeadDataLow							HeadDataGpio&=~HeadDataIOBit
//power lock IO
#define PowerLockGpio	JL_PORTC->OUT
#define PowerLockIO		IO_PORTC_08
#define PowerLockIOBit	(0x0001<<8)

#define LockPower				PowerLockGpio|=PowerLockIOBit
#define PowerOff				PowerLockGpio&=~PowerLockIOBit
// Cover sensor
#define CoverGpio	JL_PORTB->OUT
#define CoverIO		IO_PORTB_08
#define CoverIOBit	(0x0001<<08)
#define	CoverState					gpio_read(CoverIO)	//B8/C0  GZ when the cover closes then IO become low level

//power control for paper edge sensor
#define PowerPaperEdgeGpio	JL_PORTC->OUT
#define PowerPaperEdgeIO	IO_PORTC_05
#define PowerPaperEdgeIOBit	(0x0001<<5)

#define PowerPaperEdgeOff				PowerPaperEdgeGpio|=PowerPaperEdgeIOBit
#define PowerPaperEdgeOn				PowerPaperEdgeGpio&=~PowerPaperEdgeIOBit

//power control for paper edge sensor
#define GapEmitterTopGpio	JL_PORTA->OUT
#define GapEmitterTopIO	IO_PORTA_01
#define GapEmitterTopIOBit	(0x0001<<1)

#define GapEmitterTopOff			GapEmitterTopGpio|=GapEmitterTopIOBit
#define GapEmitterTopOn				GapEmitterTopGpio&=~GapEmitterTopIOBit


//power control for paper edge sensor
#define GapEmitterBottomGpio	JL_PORTC->OUT
#define GapEmitterBottomIO		IO_PORTC_06
#define GapEmitterTopIOBit		(0x0001<<6)

#define GapEmitterBottomOff			GapEmitterBottomGpio|=GapEmitterTopIOBit
#define GapEmitterBottomOn			GapEmitterBottomGpio&=~GapEmitterTopIOBit

extern PrintPage Page;
extern StepMP SMP;
extern const unsigned long  TableSpeedUS[];
void ContinueMode(StepMP *SMP);
void FixedStepsMode(StepMP *SMP);
void USBPrinterReveiveDataTask(void);
void CoverOperation(void);
void RedundantDataProcessing(bool waiting);
void SensorErrDuringPrintProcess(void);



//NVS structure
typedef struct NoneVolatileStorage
{
	unsigned int PrintPosAndGapValue;//storage the gap distance between gap sensor and print location. unite:steps default value 240
	unsigned int TemparatureAutonomousValue;//storage the temparature leve for auto adjust.when temparature reach this level ,the PWM duty ratio will decrease default value 55 degree
	unsigned int RatioADJValue;			//stroge the duty ratio decrease value 1 degree formula (temparature-TemparatureAutonomousValue)*RatioADJValue ; default value:3
	unsigned int MaximumEmptyLineValue;	//storage the maximum empty line value due to some error occured the printer will print nothing and continue to move forward,this value will limit the empty line  moveing. default:800
	unsigned int FindPaperEdgeLength;
	unsigned int PaperCutPostion;//stroge the distance in steps of the print location to cut papper location
	unsigned int PageHeightStepsMaximum;//
}NVS;







#ifdef __cplusplus
}
#endif



