/*
******************************************************************************
* @file 	  AppDriverMain.c
* @author	  Sang 2024
* @date 	  2024-12
* @brief	  Software structure and algorithm layer(application layer)
*			  This module is independent of the CPU type and is only dependent on FreeRTOS.
*
*			  This file provides firmware functions to manage the following
*			  functionalities:
*			  + Data Packet Linked List Management
*			  +
*			  +
*
*
*/
#include "AppDriverGeneric.h"//JL lib dependency
#include "AppDriver.h"
USBDP USBdp={NULL,CommIdle};//usb communication
PDataPacket PWiFiPrinterDP=NULL;//Wifi data paket structure
PDataPacket PEdrDP=NULL;//Edr bluetooth data paket structure
PDataPacket PBLEDP=NULL;//Edr bluetooth data paket structure
/**
 * @brief User define USB printer Interrupt Service Routine call back function
 * @param UsbDevice: usb device pointer;Ep:end pointer number
 * @return none
 */
 void USBPrinterReveiveDataIsr(struct usb_device_t *UsbDevice, u32 Ep)
{
	unsigned char Buffer[MAXP_SIZE_HIDOUT];// receive buffer
	LinkedListData LLData;
    UBaseType_t uxSavedInterruptStatus = taskENTER_CRITICAL_FROM_ISR();// Enter into critical area
	unsigned int NodeCount=_malloc_size(USBdp.DP);//calculate node quantity
	if(NodeCount>MaxLinkedListCount)//limit the data stream
	{
		USBdp.Status=CommSuspended;//communication suspend
		return;
	}
	unsigned int Len = usb_g_bulk_read(0,HID_EP_OUT, Buffer, MAXP_SIZE_HIDOUT,0);
	LLData.len=Len;
	LLData.data=(unsigned char*)malloc(Len*sizeof(unsigned char));
	memcpy(LLData.data,Buffer,LLData.len);
	_malloc(&USBdp.DP,LLData);//save data in linked list
	free(LLData.data);
    taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);// exit critical area
}
/**
 * @brief User define USB printer data receive function in task
 * @param UsbDevice: usb device pointer;Ep:end pointer number
 * @return none
 */
 void USBPrinterReveiveDataTask(void)
{
	if(CommSuspended==USBdp.Status)//suspend->check linked list
	{
		unsigned char Buffer[MAXP_SIZE_HIDOUT];// receive buffer
		LinkedListData LLData;
		taskENTER_CRITICAL(); //enter into the critical area
		unsigned int NodeCount=_malloc_size(USBdp.DP);//calculate node quantity
		if(NodeCount<RestartRxCount)//limit the data stream
		{
			unsigned int Len = usb_g_bulk_read(0,HID_EP_OUT, Buffer, MAXP_SIZE_HIDOUT,0);
			LLData.len=Len;
			LLData.data=(unsigned char*)malloc(Len*sizeof(unsigned char));
			memcpy(LLData.data,Buffer,LLData.len);
			_malloc(&USBdp.DP,LLData);//save data in linked list
			USBdp.Status=CommIdle;
			free(LLData.data);
		}
		taskEXIT_CRITICAL();// exit critical area
	}
}
 void WiFiPrinterReceiveDataTask(unsigned char *data,unsigned int len)
 {
	 LinkedListData LLData;
	 LLData.len=len;
	 LLData.data=(unsigned char*)malloc(LLData.len*sizeof(unsigned char));
	 memcpy(LLData.data,data,LLData.len);
	 _malloc(&PWiFiPrinterDP,LLData);//save data in linked list
	 free(LLData.data);
	 unsigned int NodeCount=_malloc_size(PWiFiPrinterDP);
	 while(NodeCount>30)
	 {
		vTaskDelay(pdMS_TO_TICKS(1));
		NodeCount=_malloc_size(PWiFiPrinterDP);
	 }
	// vTaskDelay(pdMS_TO_TICKS(100));
 }
 extern int transport_spp_flow_enable(u8 en);
 bool EdrBusy=false;
 void EdrPrinterReceiveDataISR(unsigned char *data,unsigned int len)
 {
	 LinkedListData LLData;
	 LLData.len=len;
	 LLData.data=(unsigned char*)malloc(LLData.len*sizeof(unsigned char));
	 memcpy(LLData.data,data,LLData.len);
	 _malloc(&PEdrDP,LLData);//save data in linked list
	 free(LLData.data);
	 unsigned int NodeCount=_malloc_size(PEdrDP);
	 if(NodeCount>20)
	 {
		transport_spp_flow_enable(1);
		EdrBusy=true;
		 printf("EDR=%d",NodeCount);
	 }
 }
  void EdrPrinterReceiveDataTask(void)
 {
	 unsigned int NodeCount=_malloc_size(PEdrDP);
	 if(NodeCount<10&&EdrBusy)
	 {
		transport_spp_flow_enable(0);
		EdrBusy=false;
		 printf("EDR>>");
	 }
 } 
  void BLEPrinterReceiveDataISR(unsigned char *data,unsigned int len)
 {
	 LinkedListData LLData;
	 LLData.len=len;
	 LLData.data=(unsigned char*)malloc(LLData.len*sizeof(unsigned char));
	 memcpy(LLData.data,data,LLData.len);
	 _malloc(&PBLEDP,LLData);//save data in linked list
	 free(LLData.data);
	 unsigned int NodeCount=_malloc_size(PBLEDP);
	 printf("BLE=%d",NodeCount);

 }

 // @brief CopyMemoryISR,this function uses in interrupt function-->print timer exclusive function and copies only one packet
bool CopyMemoryISR(DataPacket** DataType,LinkedListData *LLData)
{
	DataPacket Dp;
	if(_copy_memery(DataType,&Dp))//free packet and obtain data
	{
		LLData->PageNum=Dp.LLData.PageNum;	
		LLData->len=Dp.LLData.len;		//data length
		LLData->data=(unsigned char*)malloc(LLData->len*sizeof(unsigned char));//allocate memory
		memcpy(LLData->data,Dp.LLData.data,LLData->len);//abtain memory 
		_free(DataType);		//free the data packet
		free(Dp.LLData.data);	//free temporary buffer
		return true;
	}
	return false;
}
bool CopyPageNumISR(DataPacket** DataType,LinkedListData *LLData)
{
	DataPacket Dp;
	if(_copy_memery(DataType,&Dp))//free packet and obtain data
	{
		LLData->PageNum=Dp.LLData.PageNum;	
		_free(DataType);		//free the data packet
		free(Dp.LLData.data);	//free temporary buffer
		return true;
	}
	return false;
}

unsigned long PageNumCurrent(DataPacket** DataType)
{
	DataPacket Dp;
	if(_copy_memery(DataType,&Dp))//free packet and obtain data
	{
		return Dp.LLData.PageNum;;
	}
	return 0;
}

//This function uses in task
static void CopyMemoryTask(DataPacket** DataType)
{
	DataPacket Dp;
	while(_copy_memery(DataType,&Dp))//free packet and obtain data
	{
		if(PrintDataManagement(Dp.LLData.len,Dp.LLData.data)==false) //handle print data
		{
			free(Dp.LLData.data);//free temporary buffer
			return;	//print memory limitation 
		}
		_free(DataType);	//free the data packet
		free(Dp.LLData.data);	//free temporary buffer
	}
}
/**
 * @brief DataManagementTask.
 */
void DataManagementTask(void *p)
{
    int msg[16];
	int Count=0;
    while(1)
    {
    	USBPrinterReveiveDataTask();				//USB receive data stream manegement
    	EdrPrinterReceiveDataTask();				//bluetooth data flow
    	CopyMemoryTask(&USBdp.DP); 					//read usb communication linked list data and send to process
    	CopyMemoryTask(&PEdrDP);					//bluetooth
    	CopyMemoryTask(&PBLEDP);					//bluetooth
    	CopyMemoryTask(&PWiFiPrinterDP); 			//wifi printer fetch data
		__os_taskq_pend(msg, ARRAY_SIZE(msg), 10);	//task pend
    }
}
