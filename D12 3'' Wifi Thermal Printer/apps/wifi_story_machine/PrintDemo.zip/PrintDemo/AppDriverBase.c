  /*
  ******************************************************************************
  * @file    	AppDriverCommunication.c
  * @author  	Sang 2024
  * @date		2024-12
  * @brief   Encapsulate JieLi hardware layers
  *
  *
  */
#include "AppDriverGeneric.h"//JL lib dependency
#include "AppDriver.h"
#include "stdio.H"


unsigned int ADCValue[ADCMemoryLimit]={0}; //ADC value queue
const unsigned long  TableSpeedUS[31] =//Speed table for acceleration and deceleration
{//attention!!! you can modify the value of this speed table ,but the maximum steps must be set to 31 steps, otherwise error will be occured during the printing!
	10000,3000,2519,2175,1917,1717,1558,1429,1322,1232,1156,1091,1035,987,945,908,875,847,822,800,781,764,750,738,727,718,712,706,702,700,700,
};
StepMP SMP={19,0,0,false,Forward,Stopped,ModeFixSteps,500,false,false,false,false};//step motor running parameter
GAP Gap={0};
PrintPage Page={0,2400,0};

EventGroupHandle_t Printer_event_group;
unsigned long TotalLen=0;

NVS Nvs={270,55,2};
unsigned char HandleCover=false;
static void GPIOSetOut(unsigned int IO)
{
	gpio_set_die(IO, 1);//set IO digital model
	gpio_set_pull_up(IO, 1);//set IO pull up
	gpio_set_pull_down(IO, 0);//close IO pull down
	gpio_set_direction(IO, 0);//Set IO output
}
/**
 * @brief  GPIO configration.
 */
static void GPIO_Configuration(void)
{
	/*--------------step motor IO--------------*/
	
	GPIOSetOut(PortStepMotorCurrentI0IO);//PA10	 MtI0
	GPIOSetOut(PortStepMotorCurrentI1IO);//PB5  MtI1
	GPIOSetOut(PortStepMotorEnableIO);//PA6   MtEnb
	GPIOSetOut(PortStepMotorPhaseAIO);////PA5	MotoPhaseA
	GPIOSetOut(PortStepMotorPhaseBIO);//PA9	MotoPhaseB
	GPIOSetOut(PortDriverPowerPulseIO);//PB6  HdEnb pulse enb- Main power switch
	StepMotordisable;//set step motor disable
	StepMotorPhaseAHigh;//set default state
	StepMotorPhaseBHigh;//set default state
	/*--------------thermal head IO--------------*/
	GPIOSetOut(HeadstrobeIO);//PC10 strobe   PWM IO
	GPIOSetOut(HeadLatchIO);//HdLat PC7
    GPIOSetOut(HeadClkIO);//PA3	HdClk
	GPIOSetOut(HeadDataIO);//PA4	HdDatai
	HeadstrobeDisable;	//strobe IO set 0
	HeadLatchHigh;		//head latch IO set 1
	HeadClkHigh;		//Clk IO set 1
	GPIOSetOut(PowerLockIO);//PwEnb power lock IO
	LockPower;	//lock working power
	//Gz	(same C0)cover sensor
	gpio_set_die(CoverIO, 1);
	gpio_set_pull_up(CoverIO, 1);
	gpio_set_pull_down(CoverIO, 0);
	gpio_set_direction(CoverIO, 1);

	GPIOSetOut(PowerPaperEdgeIO);//PC5	GapPwm Gpio paper edge sensor emitter control
	PowerPaperEdgeOn;
	GPIOSetOut(GapEmitterTopIO);//PA1	Gap emitter on the top control
	GapEmitterTopOn;
	GPIOSetOut(GapEmitterBottomIO);//BkPwm gpio
    GapEmitterBottomOff;
	GPIOSetOut(LEDErrGpioIO);//LED
	GPIOSetOut(LEDLineGpioIO);//LED
    LEDErrTurnOff;
    LEDLineTurnOn;	
	///------------ADC----------------
	//working power on-off key-->channel 3
	gpio_set_die(IO_PORTB_01, 0);		//set analog mode
	gpio_set_pull_up(IO_PORTB_01, 0);	//close pull up
	gpio_set_pull_down(IO_PORTB_01, 0);	//close pull down
	gpio_set_direction(IO_PORTB_01, 1);	//input mode
	//Usbpower voltage -->channel 8
    gpio_set_die(IO_PORTC_09,1);
    gpio_set_pull_up(IO_PORTC_09,0);
    gpio_set_pull_down(IO_PORTC_09, 0);
    gpio_set_direction(IO_PORTC_09, 1);
	//PA7	KeyAdc ---->channel 0
	gpio_set_die(IO_PORTA_07, 0);
	gpio_set_pull_up(IO_PORTA_07, 0);
	gpio_set_pull_down(IO_PORTA_07, 0);
	gpio_set_direction(IO_PORTA_07, 1);
	//PA8	PaperAdc --->channel 1
	gpio_set_die(IO_PORTA_08, 0);
	gpio_set_pull_up(IO_PORTA_08, 0);
	gpio_set_pull_down(IO_PORTA_08, 0);
	gpio_set_direction(IO_PORTA_08, 1);
	//PB7  GapBkAdc --->channel 5
	gpio_set_die(IO_PORTB_07, 0);
	gpio_set_pull_up(IO_PORTB_07, 0);
	gpio_set_pull_down(IO_PORTB_07, 0);
	gpio_set_direction(IO_PORTB_07, 1);
	//PC1	TmAdc   ADC --->channel 9
 	gpio_set_die(IO_PORTC_01, 0);//set IO analog model
	gpio_set_pull_up(IO_PORTC_01, 0);//close IO pull up
	gpio_set_pull_down(IO_PORTC_01, 0);//close IO pull down
	gpio_set_direction(IO_PORTC_01, 1);//Set IO input
}

/**
 * @brief timer 1 interrupt callback function
 */
static ___interrupt USIRAM void Timer1CallBackMotor(void)
{
	if (TimerIntervalCON & BIT(15))//interrupt bit
	{
        TimerIntervalCON |= BIT(14);//clear interrupt bit
		PortDriverPowerPulseAvert;//invert pulse
    }
}
void SensorStatusISR(void)
{
	static int ADCPaperEdgeCount=0;
	if(CoverState)
	{
		SMP.Suspend=true;
		Page.SensorError=true;
	}
	if(ADCValue[ADCPaperEdge]>500)
	{
		ADCPaperEdgeCount++;
		if(ADCPaperEdgeCount>200)
		{
			SMP.Suspend=true;
			Page.SensorError=true;
		}
	}else
	{
		ADCPaperEdgeCount=0;
	}
}

void PrinterDataIn(unsigned char *data,unsigned char len)
{
	if(SMP.HeadPrint==false)return;
	_dev_write_spi(data,len);//SPI write data
	HeadLatchIn;			//latch data in
}
void RedundantDataProcessing(bool waiting)//use this function should be carefully as the waiting parameter would be reset the chip at some sitituations
{
	unsigned int Count=0;
	LinkedListData LLDataTempA;
	while(1)
	{
		if(CopyPageNumISR(&PrintBLink,&LLDataTempA))//delete data packet and judge remainder data page number,current page print finished
		{
			//printf("b:%d-%d>",Page.PageNum,LLDataTempA.PageNum);
			if(Page.PageNum==LLDataTempA.PageNum)//if data page changes,delete processing ends
			{
				//printf("b:%d-%d>",Page.PageNum,LLDataTempA.PageNum);
				break;
			}
			Count++;
			if(Count>25&&!waiting)//due to the remainder time isn't enought to redundant colossal data at once as to set a limitation
			{
				//printf("CX:%d",Count);
				break;
			}
			if(waiting)// this only occured in a task ,if interrupt executes the delay ,chip will be reseted immediately.
			{
				unsigned int NodeCount=_malloc_size(PrintBLink);//calculate node quantity of print buffer
				if(NodeCount) continue;
				vTaskDelay(pdMS_TO_TICKS(200));
			}
		}
		else//this situation occurs when data is the last page or the print temporary buffer isn't big enough to hold the redundant data
		{
			if(!waiting)
			{
				//printf("C:%d",Count);
				SMP.Suspend=true;//redundant data can't be removed during the gap moving ,set step motor into the stop processing
				Page.EliminateRedundanctData=true;//tell the subquent code to handle this situation
			}
			break;

		}
	}
}
void RedundantDataProcessingLastPage(void)
{
	unsigned int Count=0;
	LinkedListData LLDataTempA;
	while(1)
	{
		if(CopyPageNumISR(&PrintBLink,&LLDataTempA))//delete data packet and judge remainder data page number,current page print finished
		{
			if(Page.PageNum==LLDataTempA.PageNum)//if data page changes,delete processing ends
			{
				Count++;
				if(Count>25)//due to the remainder time isn't enought to redundant colossal data at once as to set a limitation
				{
					//printf("LX:%d",Count);
					break;
				}
			}
			else
			{
				break;
			}

		}
		else
		{
			break;
		}
	}
}

//brief:This function is a line counter for authentic label size which calculated by the gap.
void AuthenticPageMangement(void)
{
	Page.RemainderSteps--;//reminder steps in current page,subtract this value untile it become zero
	if(!Page.RemainderSteps)//change page
	{
		Gap.CountLable++;
		Page.PageNum++;//change print page
		Page.RemainderSteps=2400;//if subsequent is invalid ,use maximum value
		if(Gap.LabelLength)	//if lable length is valid then set it as the primary value of the countdown variable
		{
			Page.RemainderSteps=Gap.LabelLength;//the next page length
		}
		//printf("NS:%d\n",Page.RemainderSteps);
	}
}
//brief:This function aims to reconcile the page data with label size
void PageDataCalculation(void)
{
	bool CompensateEmptyLine=false;	//empty line output flag
	bool RedundantData=false;		//delete redundant data flag

	LinkedListData LLDataTempA;							//temporary buffer for one line
	if(_copy_PageNum(&PrintBLink,&LLDataTempA))			//read current page number
	{
		if(Page.PageNum==LLDataTempA.PageNum)			//judge page number,if page number remains unchange
		{
			AuthenticPageMangement();//calculate steps by anthentic lable heighth
			if(Page.RemainderSteps<16)
			{
				RedundantDataProcessingLastPage();
				CompensateEmptyLine=true;
			}
		}
		else//print page changes,there are two situations ,print page number changed and print page data page changed
		{
		//	printf("A:%d-%d>",Page.PageNum,LLDataTempA.PageNum);
			CompensateEmptyLine=true;//both situations need empty line output
			if(Page.PageNum>LLDataTempA.PageNum)//print page number changed,this situation means there are redundant data->actually in this situation,label gap is under the print head
			{
				RedundantDataProcessing(false);//remove the redundant data processing,don't wait,The parameter can't be set to true when function in ISR, otherwise the chip will be reset
			}
			else//this situation means the print page heighth is shorter than the label's height,we need to print empty line untile the "Page.PageNum" catches the "LLDataTempA.PageNum"
			{
				//printf(">>");
				AuthenticPageMangement();//lable reminder steps count++
			}
		}
	}
	else//this situation occurs when the page data's heighth is shorter than the lable heighth as there are no print data left none data read out(one page printting)
	{
		AuthenticPageMangement();
	}
	//----------------motor suspend condition--------------------------------------------------
	unsigned int NodeCount=_malloc_size(PrintBLink);//calculate parkets quantity
	if(NodeCount<=SMP.ACCSteps&&Page.RemainderSteps<SMP.ACCSteps)//if remainder steps lower than accelerate steps then go to decelerate process
	{
		SMP.Suspend=true;// set step motor suspend flag ,then it goes to decelerate process atomatically
	}
	else if(NodeCount<=SMP.ACCSteps&&command.PageEndFlag==false)//if the handle processing is faster than the print data in then stop the motor !
	{
		SMP.Suspend=true;
	}

	if(!CompensateEmptyLine&&NodeCount)
	{
		LinkedListData LLDataTemp;
		CopyMemoryISR(&PrintBLink,&LLDataTemp);				//read one linked list data
		PrinterDataIn(LLDataTemp.data,LLDataTemp.len);		//print one line data--->The second parameter represent the bytes one line-4inches:108;3inches:80,2inches:64
		free(LLDataTemp.data);								//release the temporary buffer
	}
	else
	{
		unsigned char Empty[108]={0};
		PrinterDataIn(Empty,108);	//in order to keep procedure consistency
	}
	//printf("%d",Page.RemainderSteps);
}
 //@brief stop step motor and close the periheral IOs
void StopStepMotor(void)
{
	StepMotordisable;
	TimerPWMCON &= BIT(0);			//Close PWM
	gpio_clear_output_channle(HeadstrobeIO, CH3_T3_PWM_OUT);
	HeadstrobeDisable;				//close PWM IO
	unsigned char DataIn[108]={0};
	PrinterDataIn(DataIn,108);
	printf("Step motor stopped!\n");
	SMP.Status=Stopped;				//step motor status
}
//@brief:This function serves as the core algorithm for dynamic page adjustment based on the gap, which occurs only when the label gap crosses the gap sensor.one page only execuate once!
void PageCompensationByGap(void)
{
	unsigned int EStimateValueA,EStimateValueB,RemainderSteps;
	if(Gap.LabelLength<Nvs.PrintPosAndGapValue&&Gap.LabelLength)//Authentic page heighth is shorter than the "PrintPosAndGapValue"
	{
		unsigned int Temp=Nvs.PrintPosAndGapValue-7;
		unsigned int LableHeight;
		LableHeight=Gap.LabelLength;
		bool DragFlag=false;
		for(unsigned int i=1;i<5;i++)//Estimate process
		{
			if(Temp>i*LableHeight)
			{
				EStimateValueA=Temp-i*LableHeight; //estimateA: left steps in the page
				//printf("&%d:%d-%d",i,EStimateValueA,Page.RemainderSteps);
				if(EStimateValueA+40>Page.RemainderSteps&&EStimateValueA<Page.RemainderSteps+40)
				{
					if(Page.RemainderSteps<20)//this situation means the print header is above the gap,don't need to protract the print;the print process is complicated any situation may occured
					{
						if(Page.RemainderSteps>EStimateValueA)
							Page.RemainderSteps=EStimateValueA;
						//printf("1:%d",Page.RemainderSteps);
					}
					else
					{
						Page.RemainderSteps=EStimateValueA;
						//printf("2:%d",Page.RemainderSteps);
					}
					if(!Page.RemainderSteps)Page.RemainderSteps=1;
					break;
				}
			}
			else//special situation print above the lable gap
			{

				EStimateValueA=i*LableHeight-Temp; //estimateA: left steps in the page
				//printf("#%d:%d-%d",i,EStimateValueA,Page.RemainderSteps);
				if(EStimateValueA+40>Page.RemainderSteps&&EStimateValueA<Page.RemainderSteps+40)
				{
					//printf("X%d:%d-%d",i,Gap.LabelLength,Page.RemainderSteps);
					if(Gap.LabelLength>Page.RemainderSteps&&Page.RemainderSteps<20)
					{
						Gap.LabelLength-=Page.RemainderSteps;
						Page.RemainderSteps=1;
						AuthenticPageMangement();
					}
					else
					{
						Page.RemainderSteps=Temp;
					}
					if(!Page.RemainderSteps)Page.RemainderSteps=1;
					//printf("Y:%d",Page.RemainderSteps);
				}
				else
				{
					DragFlag=true;
				}
				//printf(">>");
				break;
			}
		}
		if(DragFlag)
		{
			//printf("D:%d",Page.RemainderSteps);
			for(int j=1;j<5;j++)
			{
				if(Temp<j*Gap.LabelLength)
				{
					if(j==1)
						Page.RemainderSteps=1;
					else
						Page.RemainderSteps=Temp-(j-1)*Gap.LabelLength;
					break;
				}
			}
			if(!Page.RemainderSteps)Page.RemainderSteps=1;
			//printf("E:%d",Page.RemainderSteps);
		}
	}
	else
	{
		if(Gap.LabelLength)
		{
			//printf("R:%d\n",Page.RemainderSteps);
			if(Page.RemainderSteps>Nvs.PrintPosAndGapValue/2)//there is a special situation when the label's heighth approximate  to the "PrintPosAndGapValue"
				Page.RemainderSteps=Nvs.PrintPosAndGapValue;
		}
		else// only occured at the first page when the page size is super bigger than "PrintPosAndGapValue"
		{
			Page.RemainderSteps=Nvs.PrintPosAndGapValue;
		}
		//printf("X:%d\n",Page.RemainderSteps);
	}

}

void GapCalculate(void)
{
	Gap.StepsCount++;// record Gap steps
	if(ADCValue[ADCGAPSensor]<500)
	{
		Gap.CountGap=(Gap.CountGap<<1)|0x01;
	}
	else
	{
		Gap.CountGap>>=1;
	}
//	printf("ADC:%d-%02X\n",ADCValue[ADCGAPSensor],Gap.CountGap);
	if(Gap.CountGap==0x0f&&Gap.GapIn==false)
	{
		if(Gap.StepsGapPos)//gap data exist
		{
			Gap.LabelLength=Gap.StepsCount-Gap.StepsGapPos;//total length of one label include the gap height
			Gap.StepsGapPos=Gap.StepsCount;//record steps
			//printf("P:%d\n",Gap.LabelLength);
			if(Gap.LableLengthCP)
				if(Gap.LabelLength+5<Gap.LableLengthCP||Gap.LabelLength>Gap.LableLengthCP+5)
				{
					Gap.LabelLength=Gap.LableLengthCP;
				}
		}
		Gap.StepsGapPos=Gap.StepsCount;//record steps

		//printf("P:%d\n",Gap.LabelLength);
		Gap.GapIn=true;
	}
	if(Gap.GapIn)
	{
		if(Gap.CountGap==0x01)
		{
			Gap.LabelGapLength=Gap.StepsCount-Gap.StepsGapPos;
			Gap.GapIn=false;
			printf("G:%d",Gap.LabelGapLength);
			if(SMP.CalculateCompensate)
				PageCompensationByGap();///print page compensate algorithm
			if(Gap.LabelGapLength>8*10)//if gap heighth exceed 10mm,some labels are lost, stop the motor and handle this issue manually
			{
				SMP.Suspend=true;		//motor enter into dec process
				Page.SensorError=true;//set status sensor detects errors
				printf("G:%d",Gap.LabelGapLength);
			}
		}
	}
}
void ThermometerADJ(void)
{
	if(ADCValue[ADCThermoneter]<512)//50 degree
	{
		unsigned long DensityADJ;
		DensityADJ=command.density;
		if(command.density>(512-ADCValue[ADCThermoneter])/3)
			DensityADJ=command.density-(512-ADCValue[ADCThermoneter])/3;
		if(DensityADJ<35)
			DensityADJ=35;
		TimerPWMPWM= TimerPWMPRD*((unsigned long)DensityADJ)/100;//set density duty ration
	}
}
void FindFaperEdgeISR(void)
{
	static unsigned int PaperSensor=0xff;
	if(ADCValue[ADCPaperEdge]>500)
		Gap.CountPaper=(Gap.CountPaper<<1)|0x01;
	else
		Gap.CountPaper>>=1;
	if(Gap.CountPaper==0x0f||SMP.CurrentSteps>SMP.StepsFixedValue)
	{
		SMP.Suspend=true;
	}
}
/**
 * @brief step motor phase switching
 */
static void PhaseSwitching(void)
{
	static unsigned char PhaseSerial=0;//phase flag of the step motor
	switch(PhaseSerial%4)//phase switching
	{
		case 0:Step1IO;break;
		case 1:Step2IO;break;
		case 2:Step3IO;break;
		default:Step4IO;break;
	}
	Forward==SMP.Dir?PhaseSerial++:PhaseSerial--;//move direction
	SMP.Mode==ModeContinue?ContinueMode(&SMP):FixedStepsMode(&SMP);//successive steps or fixed steps
	if(Forward==SMP.Dir&&SMP.RecordGap)//when move forward and find gap variable set then execute find gap function
	{
		GapCalculate();
	}
}

//call back function for timer4 interrupt->this timer uses to control the step motor
static ___interrupt USIRAM void Timer4CallBackMotor(void)
{
	// UBaseType_t uxSavedInterruptStatus = taskENTER_CRITICAL_FROM_ISR();// Enter into critical area
    if (TimerStepMotorCON & BIT(15))//interrupt bit
	{
        TimerStepMotorCON |= BIT(14);//clear interrupt bit
        if(SMP.StepMotorFinished)//if decelerate finished then stop step motor operation
        {
        	StopStepMotor();//stop step motor
        }
		else
		{
			if(SMP.FindPaperEdge)//subsequent code is the find paper edge algorithm
			{
				FindFaperEdgeISR();//this function uses to find the paper edge
			}
			else if(SMP.HeadPrint==true)//subsequent code is the head print algorithm
			{
				PageDataCalculation();//page data calculation and print head  data output process
				ThermometerADJ();//when temperature increases decreases PWM ratio duty
			}
	        PhaseSwitching();// phase switching ,period time reload,lable size calculate process
	        SensorStatusISR();//check papersensor and cover status
		}
    }
	// taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);// exit critical area
}
void TwinkleLedErr(void)
{
	LEDErrTurnOn;vTaskDelay(pdMS_TO_TICKS(500));
	LEDErrTurnOff;vTaskDelay(pdMS_TO_TICKS(500));
}
void SensorErrDuringPrintProcess(void)
{
	while(!CoverState)
	{
		TwinkleLedErr();
	}
}
//step motor starting entrance
void StepMotorStart(StepMP CurrentSMP)
{
	if(SMP.Status==Running) return;//if step motor running return to task idle
	Page.EliminateRedundanctData=false;//this variable will be set when the page's heighth supasses the label height a lot.
	Page.SensorError=false;
	Gap.GapIn=false;
	SMP=CurrentSMP;
	SMP.Status=Running;
	if(SMP.Mode==ModeFixSteps)
	{
		if(SMP.StepsFixedValue<SMP.ACCSteps*2)
		{
			SMP.ACCSteps=SMP.StepsFixedValue/2;
		}
	}
	if(SMP.HeadPrint==true)
	{
		gpio_output_channle(HeadstrobeIO, CH3_T3_PWM_OUT);
		TimerPWMPWM= TimerPWMPRD*((unsigned long)command.density)/100;//set density duty ration
		TimerPWMCON |= BIT(0);
		if(Page.ContinuePrint==false)
		{
			if(Gap.LabelLength)//if page length is valid use this page length as the pageheight;This only happened when is label height is shorter than GAP-Print gap
			{
				Page.RemainderSteps=Gap.LabelLength;//
			}
			else
				Page.RemainderSteps=2400;
		}
		printf("Set page height Page.RemainderSteps:%d",Page.RemainderSteps);
	}
	Gap.CountLable=0;
	Gap.StepsCount=0;
	Gap.StepsGapPos=0;
	StepMotorIOEnable;
	StepMotorCurrentOn;
	TimerIntervalCON|=BIT(0);
	vTaskDelay(pdMS_TO_TICKS(1));		//delay100ms
	TimerStepMotorCON|=BIT(0);
	printf("step motor runing...\n");
}
void FindFaperEdgeStart(void)//find paper edge configuration and operation queue
{
	if(ADCValue[ADCPaperEdge]<500)//paper on the edge sensor
	{
		printf("Paper is on the edge sensor..\n");
		StepMP StepMPFindEdge={9,0,0,false,Backward,Stopped,ModeContinue,1200,false,false,true,false};//1200 is the storage parameter
		StepMotorStart(StepMPFindEdge);
		while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
		StepMP MPCutPos={9,0,0,false,Forward,Stopped,ModeFixSteps,86,false,false,false,false};
		StepMotorStart(MPCutPos);
		while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
		printf("Find paper edge!\n");
		vTaskDelay(pdMS_TO_TICKS(100));
	}
	else
	{
		printf("No paper in the printer..\n");
		while(!CoverState) vTaskDelay(pdMS_TO_TICKS(100));//wait for cover open
	}
}

void FindGapOperation(void)
{

	GAP GapT={0};
	Gap.LableLengthCP=0;
	printf("Find gap..\n");
	Gap=GapT;//when cover open then set default value
	StepMP StepMPFindEdge={9,0,0,false,Forward,Stopped,ModeFixSteps,800,false,false,false,true,false};
	StepMotorStart(StepMPFindEdge);
	while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
	printf("Find gap end\n");
	vTaskDelay(pdMS_TO_TICKS(100));
	StepMP StepMPFindEdgeA={9,0,0,false,Backward,Stopped,ModeFixSteps,800,false,false,false,false,false};
	StepMotorStart(StepMPFindEdgeA);
	while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(100));//waiting for step motor stopped
	vTaskDelay(pdMS_TO_TICKS(100));
	if(Gap.LabelLength)
	{
		printf("find label paper size:%d\n",Gap.LabelLength);
	}
	else
	{
		printf("find label paper failed LabelLength:%d;Gap:%d\n",Gap.LabelLength,Gap.LabelGapLength);
	}
	//xEventGroupSetBits(Printer_event_group, PrinterReady_BIT);
	Gap.paperPosition=CutPos;
	Gap.StepsCount=0;	//reseek the gap!!
	Gap.LableLengthCP=0;
	if(Gap.LabelLength)//if found the label length when power on or cover close operation
	{
		Gap.LableLengthCP=Gap.LabelLength;
		printf("lable size calculate succesful!-%d\n",Gap.LableLengthCP);
	}


}
void CoverOperation(void)
{
	static bool CoverCloseOperation=true;
	if(CoverState)
	{
		xEventGroupClearBits(Printer_event_group,PrinterReady_BIT);
		printf("cover opens,waiting cover closed!-->\n");
		while(CoverState) TwinkleLedErr();
		CoverCloseOperation=true;
		printf("cover closes..\n");
	}
	else
	{
		if(CoverCloseOperation)//only execuate when the power on situation
		{
			CoverCloseOperation=false;
			while(SMP.Status==Running) vTaskDelay(pdMS_TO_TICKS(200));
			FindFaperEdgeStart();//when power on and the cover is closed, then execute the find edge algorithm
			FindGapOperation();//when the label heighth shorter than the distance between gap and print position, this function is working
		}
		xEventGroupSetBits(Printer_event_group, PrinterReady_BIT);//cover closed and find paper edge finished
	}
}

void PeripheralApparatusTask(void *p)//this task manage cover,paper..
{
    int msg[16],i;
	unsigned char MAC[128];
    while(1)
    {
		malloc_stats();
		printf("T:%d\n",ADCValue[ADCThermoneter]);
		__os_taskq_pend(msg, ARRAY_SIZE(msg), 1000);//task pend
    }
}
 //@brief Entrance APPPrintDemoMain
void APPPrintDemoMain(void)
{
	GPIO_Configuration();//GPIO configuration
	vTaskDelay(pdMS_TO_TICKS(4000));
	printf("APPPrintDemoMain entrance---------->\r\n");
	Printer_event_group=xEventGroupCreate();//Initial events groups
	_dev_open("timer4",0);//step motor timer
	_dev_open("timer1",0);//step motor timer
	_dev_open("timer3pwm",0);//step motor timer
	request_irq(IRQ_TIMER4_IDX, 3, Timer4CallBackMotor, 0);//register interrupt to callback function
	request_irq(IRQ_TIMER1_IDX, 3, Timer1CallBackMotor, 0);//register interrupt to callback function
	_dev_open("spi2",0);//open device SPI2
	adc_init();  //use JL API to initialize ADC
	StopStepMotor();//clear print buffer,set motor status to stop
	task_create(DataManagementTask, NULL, "DataManagementTask");
	task_create(PrintTask, NULL, "PrintTask");//communication data management task
	task_create(PeripheralApparatusTask, NULL, "PeripheralApparatusTask");//peripheral device status management
}
late_initcall(APPPrintDemoMain);


